# Delta Key Bot Railway Deploy

## What this is
Telegram bot for Delta Executor keys.

## Required files
- `artifacts/api-server/package.json`
- `artifacts/api-server/build.mjs`
- `artifacts/api-server/tsconfig.json`
- `artifacts/api-server/src/index.ts`
- `artifacts/api-server/src/app.ts`
- `artifacts/api-server/src/bot/index.ts`
- `artifacts/api-server/src/bot/bypass.ts`
- `artifacts/api-server/src/lib/logger.ts`

## Railway deploy
1. Push the project to GitHub.
2. Create a new Railway project.
3. Connect your GitHub repo.
4. Select the `artifacts/api-server` service.
5. Add env vars:
   - `TELEGRAM_BOT_TOKEN`
   - `PORT` = `8080` if Railway asks for one manually.
6. Use this start command:
   - `pnpm --filter @workspace/api-server run dev`
7. Deploy.

## If Railway asks for build command
Use:
- `pnpm install`

## If Railway asks for start command
Use:
- `pnpm --filter @workspace/api-server run dev`

## Local run
1. `pnpm install`
2. Set `TELEGRAM_BOT_TOKEN`
3. Run `pnpm --filter @workspace/api-server run dev`

## Notes
- The server reads `PORT` from env.
- The bot starts from `src/index.ts`.
- The bot has menu, profile, instructions, support, and auto key extraction.
