import { Bot, InlineKeyboard, session } from "grammy";
import { logger } from "../lib/logger";
import { bypassPlatorelay } from "./bypass";

interface SessionData {
  step: "idle" | "waiting_link";
  keysGenerated: number;
}

const token = process.env["TELEGRAM_BOT_TOKEN"];
if (!token) throw new Error("TELEGRAM_BOT_TOKEN is not set");

export const bot = new Bot<{ session: SessionData }>(token);

bot.use(
  session({
    initial: (): SessionData => ({ step: "idle", keysGenerated: 0 }),
  }),
);

// ── helpers ───────────────────────────────────────────────────────────────────

function esc(t: string) {
  return t.replace(/[_*[\]()~`>#+=|{}.!\\\-]/g, "\\$&");
}

function mainMenu() {
  return new InlineKeyboard()
    .text("🔑 Получить ключ", "getkey")
    .row()
    .text("👤 Мой профиль", "profile")
    .text("📖 Как использовать", "howto")
    .row()
    .text("🆘 Помощь", "support");
}

const WELCOME = `
🔷 *Delta Key Bot*

Автоматически получаю ключи для *Delta Executor* в Roblox \\— без ручного прохождения заданий\\.

*Как это работает:*
├ Открой Delta Executor и нажми *Get Key*
├ Скопируй ссылку и отправь мне
└ Получи ключ через *5–30 секунд* ⚡

👇 Нажми кнопку ниже или просто отправь ссылку
`.trim();

// ── /start ────────────────────────────────────────────────────────────────────

bot.command("start", async (ctx) => {
  ctx.session.step = "idle";
  await ctx.reply(WELCOME, {
    parse_mode: "MarkdownV2",
    reply_markup: mainMenu(),
  });
});

// ── Profile ───────────────────────────────────────────────────────────────────

bot.callbackQuery("profile", async (ctx) => {
  await ctx.answerCallbackQuery();
  const u = ctx.from;
  const name = esc([u.first_name, u.last_name].filter(Boolean).join(" "));
  const uname = u.username ? `@${esc(u.username)}` : "_не указан_";

  const badge =
    ctx.session.keysGenerated >= 10
      ? "💎 Опытный"
      : ctx.session.keysGenerated >= 3
        ? "⭐ Активный"
        : "🆕 Новичок";

  await ctx
    .editMessageText(
      `👤 *Мой профиль*\n\n` +
        `🆔 ID: \`${u.id}\`\n` +
        `👤 Имя: ${name}\n` +
        `🔗 Username: ${uname}\n\n` +
        `🔑 Получено ключей: *${ctx.session.keysGenerated}*\n` +
        `🏆 Статус: ${badge}`,
      {
        parse_mode: "MarkdownV2",
        reply_markup: new InlineKeyboard()
          .text("🔑 Получить ключ", "getkey")
          .row()
          .text("⬅️ Назад", "back"),
      },
    )
    .catch(() => {});
});

// ── Get Key ───────────────────────────────────────────────────────────────────

bot.callbackQuery("getkey", async (ctx) => {
  await ctx.answerCallbackQuery();
  ctx.session.step = "waiting_link";
  await ctx
    .editMessageText(
      `🔑 *Получение ключа*\n\n` +
        `Отправь ссылку из Delta Executor:\n\n` +
        `\`https://auth\\.platorelay\\.com/a\\?d\\=\\.\\.\\.\`\n\n` +
        `_Где взять ссылку:_\n` +
        `1\\. Открой Delta Executor\n` +
        `2\\. Нажми кнопку *Get Key*\n` +
        `3\\. Скопируй ссылку из браузера\n` +
        `4\\. Вставь сюда и отправь`,
      {
        parse_mode: "MarkdownV2",
        reply_markup: new InlineKeyboard()
          .text("📖 Инструкция", "howto")
          .row()
          .text("❌ Отмена", "back"),
      },
    )
    .catch(() => {});
});

// ── How To ────────────────────────────────────────────────────────────────────

bot.callbackQuery("howto", async (ctx) => {
  await ctx.answerCallbackQuery();
  await ctx
    .editMessageText(
      `📖 *Инструкция*\n\n` +
        `*Шаг 1* — Открой Delta Executor на телефоне\n\n` +
        `*Шаг 2* — Нажми кнопку 🔑 *Get Key*\n\n` +
        `*Шаг 3* — Браузер откроет ссылку вида:\n` +
        `\`auth\\.platorelay\\.com/a\\?d\\=\\.\\.\\.\`\n\n` +
        `*Шаг 4* — Скопируй всю ссылку из адресной строки\n\n` +
        `*Шаг 5* — Отправь ссылку мне — я сделаю всё сам ⚡\n\n` +
        `⚠️ _Каждая ссылка одноразовая и действует 24 часа_`,
      {
        parse_mode: "MarkdownV2",
        reply_markup: new InlineKeyboard()
          .text("🔑 Получить ключ", "getkey")
          .row()
          .text("⬅️ Назад", "back"),
      },
    )
    .catch(() => {});
});

// ── Support ───────────────────────────────────────────────────────────────────

bot.callbackQuery("support", async (ctx) => {
  await ctx.answerCallbackQuery();
  await ctx
    .editMessageText(
      `🆘 *Помощь*\n\n` +
        `*Не удалось получить ключ*\n` +
        `→ Ссылка уже использована или устарела\n` +
        `→ Открой Delta Executor и получи новую ссылку\n\n` +
        `*Неверный формат ссылки*\n` +
        `→ Ссылка должна начинаться с:\n` +
        `\`https://auth\\.platorelay\\.com\`\n\n` +
        `*Бот не отвечает*\n` +
        `→ Напиши /start чтобы перезапустить\n\n` +
        `_Delta Key Bot — работает автоматически, без регистрации_`,
      {
        parse_mode: "MarkdownV2",
        reply_markup: new InlineKeyboard()
          .text("⬅️ Назад", "back"),
      },
    )
    .catch(() => {});
});

// ── Back ──────────────────────────────────────────────────────────────────────

bot.callbackQuery("back", async (ctx) => {
  await ctx.answerCallbackQuery();
  ctx.session.step = "idle";
  await ctx
    .editMessageText(WELCOME, { parse_mode: "MarkdownV2", reply_markup: mainMenu() })
    .catch(() => {});
});

// ── Text messages ─────────────────────────────────────────────────────────────

bot.on("message:text", async (ctx) => {
  const text = ctx.message.text.trim();
  if (text.startsWith("/")) return;

  const isLink = text.startsWith("http://") || text.startsWith("https://");

  if (!isLink) {
    if (ctx.session.step === "waiting_link") {
      await ctx.reply(
        `⚠️ Нужна ссылка, начинающаяся с \`https://\`\n\n_Скопируй ссылку из браузера после нажатия Get Key в Delta Executor_`,
        {
          parse_mode: "MarkdownV2",
          reply_markup: new InlineKeyboard()
            .text("📖 Как получить ссылку", "howto")
            .row()
            .text("❌ Отмена", "back"),
        },
      );
    } else {
      await ctx.reply(WELCOME, { parse_mode: "MarkdownV2", reply_markup: mainMenu() });
    }
    return;
  }

  const isSupportedLink =
    text.includes("platorelay.com") ||
    text.includes("platoboost") ||
    text.includes("loot-link.com") ||
    text.includes("lootdest.com") ||
    text.includes("linkvertise.com");

  if (!isSupportedLink) {
    await ctx.reply(
      `❌ *Ссылка не поддерживается*\n\n` +
        `Мне нужна ссылка из Delta Executor вида:\n` +
        `\`https://auth\\.platorelay\\.com/a\\?d\\=\\.\\.\\.\`\n\n` +
        `_Открой Delta Executor → нажми Get Key → скопируй ссылку_`,
      {
        parse_mode: "MarkdownV2",
        reply_markup: new InlineKeyboard()
          .text("📖 Инструкция", "howto")
          .row()
          .text("🏠 Главное меню", "back"),
      },
    );
    return;
  }

  ctx.session.step = "idle";

  const processingMsg = await ctx.reply(
    `⏳ *Обрабатываю ссылку\\.\\.\\.* \n\n` +
      `Прохожу защиту и получаю ключ — это займёт *5–30 секунд*\\.`,
    { parse_mode: "MarkdownV2" },
  );

  const startTime = Date.now();

  try {
    const key = await bypassPlatorelay(text);
    const elapsed = esc(((Date.now() - startTime) / 1000).toFixed(1));

    if (key) {
      ctx.session.keysGenerated += 1;
      await ctx.api.editMessageText(
        ctx.chat.id,
        processingMsg.message_id,
        `✅ *Ключ получен за ${elapsed} сек*\n\n` +
          `\`${esc(key)}\`\n\n` +
          `_Нажми на ключ чтобы скопировать, затем вставь в Delta Executor_`,
        {
          parse_mode: "MarkdownV2",
          reply_markup: new InlineKeyboard()
            .text("🔑 Получить ещё один ключ", "getkey")
            .row()
            .text("🏠 Главное меню", "back"),
        },
      );
    } else {
      await ctx.api.editMessageText(
        ctx.chat.id,
        processingMsg.message_id,
        `❌ *Не удалось получить ключ*\n\n` +
          `Возможные причины:\n` +
          `• Ссылка уже была использована\n` +
          `• Срок действия ссылки истёк\n\n` +
          `_Открой Delta Executor и получи новую ссылку_`,
        {
          parse_mode: "MarkdownV2",
          reply_markup: new InlineKeyboard()
            .text("🔄 Попробовать снова", "getkey")
            .row()
            .text("🏠 Главное меню", "back"),
        },
      );
    }
  } catch (err) {
    logger.error({ err }, "Key extraction failed");
    await ctx.api
      .editMessageText(
        ctx.chat.id,
        processingMsg.message_id,
        `⚠️ *Произошла ошибка*\n\n_Попробуй ещё раз или получи новую ссылку в Delta Executor_`,
        {
          parse_mode: "MarkdownV2",
          reply_markup: new InlineKeyboard().text("🔄 Попробовать снова", "getkey"),
        },
      )
      .catch(() => {});
  }
});

bot.catch((err) => {
  logger.error({ err: err.error, update: err.ctx?.update }, "Bot error");
});

export async function startBot() {
  logger.info("Starting Delta Key Bot...");
  bot.start({
    onStart: (info) => {
      logger.info({ username: info.username }, "Delta Key Bot started");
    },
  });
}
