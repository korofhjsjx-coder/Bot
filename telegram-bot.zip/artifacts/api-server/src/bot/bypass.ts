import { logger } from "../lib/logger";
import axios from "axios";

const TIMEOUT = 60000;

const NIX_CHROMIUM =
  "/nix/store/0n9rl5l9syy808xi9bk4f6dhnfrvhkww-playwright-browsers-chromium/chromium-1080/chrome-linux/chrome";

function extractKeyFromText(text: string): string | null {
  const freeMatch = text.match(/FREE_[a-f0-9]{32}/i);
  if (freeMatch) return freeMatch[0]!;

  const uuidMatch = text.match(
    /[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}/i
  );
  if (uuidMatch) return uuidMatch[0]!;

  const patterns = [
    /"key"\s*:\s*"([A-Za-z0-9_\-]{10,64})"/,
    /Your key[:\s]+([A-Za-z0-9_\-]{10,64})/i,
    /key[:\s=]+([A-Za-z0-9_\-]{16,64})/i,
  ];
  for (const pat of patterns) {
    const m = text.match(pat);
    if (m?.[1]) return m[1]!;
  }
  return null;
}

function extractKeyFromJson(obj: unknown): string | null {
  if (!obj || typeof obj !== "object") return null;
  const o = obj as Record<string, unknown>;

  // Handle nested data structure: {"success":true,"data":{"key":"..."}}
  if (o["data"] && typeof o["data"] === "object") {
    const inner = extractKeyFromJson(o["data"]);
    if (inner) return inner;
  }

  const key = o["key"] ?? o["result"] ?? o["token"];
  if (typeof key === "string" && key.length > 5) return key;
  return null;
}

function extractTicketFromUrl(url: string): string | null {
  try {
    const u = new URL(url);
    return u.searchParams.get("d") ?? u.searchParams.get("ticket");
  } catch {
    return null;
  }
}

async function tryDirectApi(ticket: string): Promise<string | null> {
  const statusUrl = `https://auth.platorelay.com/api/session/status?ticket=${encodeURIComponent(ticket)}`;
  logger.info({ statusUrl }, "Trying direct session/status API");
  try {
    const res = await axios.get(statusUrl, {
      timeout: 10000,
      headers: {
        "User-Agent":
          "Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.6312.105 Mobile Safari/537.36",
        "Accept": "application/json, text/plain, */*",
        "Accept-Language": "en-US,en;q=0.9",
        "Referer": "https://auth.platorelay.com/",
        "Origin": "https://auth.platorelay.com",
      },
    });
    logger.info({ data: res.data }, "Direct API response");
    return extractKeyFromJson(res.data);
  } catch (err: unknown) {
    const e = err as { response?: { status?: number; data?: unknown }; message?: string };
    logger.warn(
      { status: e.response?.status, data: e.response?.data, msg: e.message },
      "Direct API failed, falling back to browser"
    );
    return null;
  }
}

async function bypassWithBrowser(url: string): Promise<string | null> {
  const { chromium } = await import("playwright-core");

  let browser: Awaited<ReturnType<typeof chromium.launch>> | null = null;

  try {
    browser = await chromium.launch({
      executablePath: NIX_CHROMIUM,
      headless: true,
      args: [
        "--no-sandbox",
        "--disable-setuid-sandbox",
        "--disable-dev-shm-usage",
        "--disable-gpu",
        "--disable-blink-features=AutomationControlled",
      ],
    });

    logger.info({ version: browser.version() }, "Browser launched");

    const context = await browser.newContext({
      userAgent:
        "Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.6312.105 Mobile Safari/537.36",
      viewport: { width: 390, height: 844 },
      isMobile: true,
      locale: "en-US",
      extraHTTPHeaders: {
        "Accept-Language": "en-US,en;q=0.9",
      },
    });

    const page = await context.newPage();

    let capturedKey: string | null = null;

    page.on("response", async (res) => {
      try {
        const resUrl = res.url();
        const ct = res.headers()["content-type"] ?? "";
        if (!ct.includes("json")) return;
        if (
          !resUrl.includes("plato") &&
          !resUrl.includes("boost") &&
          !resUrl.includes("session")
        )
          return;
        logger.info({ url: resUrl, status: res.status() }, "Intercepted response");
        const body = await res.json().catch(() => null);
        if (!body) return;
        logger.info({ body }, "JSON body");
        const k = extractKeyFromJson(body);
        if (k && !capturedKey) capturedKey = k;
      } catch {}
    });

    logger.info({ url }, "Navigating to platorelay...");
    try {
      await page.goto(url, { waitUntil: "networkidle", timeout: TIMEOUT });
    } catch {
      // timeout is ok, we just need to see the page
    }
    await page.waitForTimeout(3000);

    const bodyText = await page.evaluate(() => document.body.innerText);
    logger.info({ text: bodyText.slice(0, 500) }, "Initial page text");

    const earlyKey = extractKeyFromText(bodyText) ?? capturedKey;
    if (earlyKey) return earlyKey;

    // Try clicking Continue or first visible button
    logger.info("Looking for Continue button...");
    let clicked = false;
    try {
      const continueBtn = page.getByRole("button", { name: /continue/i });
      if (await continueBtn.isVisible({ timeout: 5000 })) {
        logger.info("Clicking Continue...");
        await continueBtn.click();
        clicked = true;
        await page.waitForTimeout(10000);
      }
    } catch {
      try {
        const firstBtn = page.locator("button").first();
        if (await firstBtn.isVisible({ timeout: 3000 })) {
          const txt = await firstBtn.innerText().catch(() => "");
          logger.info({ txt }, "Clicking first button");
          await firstBtn.click();
          clicked = true;
          await page.waitForTimeout(8000);
        }
      } catch {}
    }

    if (capturedKey) return capturedKey;

    if (clicked) {
      const afterText = await page.evaluate(() => document.body.innerText);
      logger.info({ text: afterText.slice(0, 500) }, "After click text");
      const afterKey = extractKeyFromText(afterText) ?? capturedKey;
      if (afterKey) return afterKey;
    }

    // Try task buttons
    try {
      const allBtns = await page.locator("button, a[href]").all();
      for (const btn of allBtns.slice(0, 10)) {
        const txt = await btn.innerText().catch(() => "");
        if (/watch|visit|claim|complete|task|continue|next/i.test(txt)) {
          logger.info({ txt }, "Clicking task button");
          await btn.click().catch(() => {});
          await page.waitForTimeout(3000);
          if (capturedKey) return capturedKey;
          const t = await page.evaluate(() => document.body.innerText);
          const k = extractKeyFromText(t);
          if (k) return k;
        }
      }
    } catch {}

    // Final wait
    await page.waitForTimeout(8000);
    if (capturedKey) return capturedKey;

    const finalText = await page.evaluate(() => document.body.innerText);
    logger.info({ text: finalText.slice(0, 500) }, "Final page text");
    return extractKeyFromText(finalText);
  } catch (err) {
    logger.error({ err }, "Browser bypass error");
    return null;
  } finally {
    await browser?.close().catch(() => {});
  }
}

export async function bypassPlatorelay(url: string): Promise<string | null> {
  logger.info({ url }, "bypassPlatorelay called");

  // Step 1: Try direct API call (fast path)
  const ticket = extractTicketFromUrl(url);
  if (ticket) {
    const directKey = await tryDirectApi(ticket);
    if (directKey) {
      logger.info({ directKey }, "Got key via direct API");
      return directKey;
    }
  }

  // Step 2: Browser fallback
  logger.info("Falling back to browser...");
  return bypassWithBrowser(url);
}
